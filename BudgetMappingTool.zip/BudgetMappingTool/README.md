# Budget Mapping Tool – Starter Kit

This pack gives you a demo-ready implementation skeleton that maps production budgets to a Chart of Accounts (US or CAD), with an Excel front-end and a Python backend for matching, validation, exceptions, a change log, PDF export, and AI-style change notes.

See README inside for install & demo steps.
