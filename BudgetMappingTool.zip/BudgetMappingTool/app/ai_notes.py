
import os
from typing import List, Dict

def _basic_notes(changes: List[Dict]) -> str:
    if not changes:
        return "No significant mapping changes detected."
    lines = ["Key mapping notes:"]
    by_code = {}
    for ch in changes:
        code = ch.get("Mapped_Account_Code","(unknown)")
        by_code.setdefault(code, 0)
        by_code[code] += 1
    for code, cnt in sorted(by_code.items(), key=lambda x: -x[1]):
        lines.append(f"- {cnt} line(s) mapped to {code} ({changes[0].get('Mapped_Account_Name','')}).")
    return "\n".join(lines)

def generate_ai_notes(changes: List[Dict], use_ai: bool=False, provider: str="openai", model: str="gpt-4o-mini") -> str:
    """
    Offline-friendly. If use_ai=True and OPENAI_API_KEY is set, will try OpenAI.
    Extend similarly for Gemini if desired.
    """
    if not use_ai:
        return _basic_notes(changes)

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return _basic_notes(changes)

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        summary_input = "Summarize the following budget mapping changes with simple, finance-friendly bullet points:\n" + str(changes)
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role":"user","content":summary_input}],
            temperature=0.2,
        )
        return resp.choices[0].message.content.strip()
    except Exception:
        return _basic_notes(changes)
