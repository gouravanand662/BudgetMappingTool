
from typing import List, Dict
def validate_row(row: Dict, valid_codes: set) -> List[str]:
    errors = []
    if not str(row.get("Mapped_Account_Code","")).strip():
        errors.append("Missing mapped account code")
    if row.get("Mapped_Account_Code","") and row["Mapped_Account_Code"] not in valid_codes:
        errors.append("Invalid COA code")
    amt = row.get("Amount", "")
    try:
        if float(amt) == 0.0:
            errors.append("Zero or missing amount")
    except Exception:
        errors.append("Zero or missing amount")
    return errors
