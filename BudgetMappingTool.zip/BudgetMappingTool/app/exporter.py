
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch

def export_summary_exceptions_pdf(path: str, summary: dict, exceptions: list):
    c = canvas.Canvas(path, pagesize=LETTER)
    width, height = LETTER
    y = height - 1*inch
    c.setFont("Helvetica-Bold", 14)
    c.drawString(1*inch, y, "Budget Mapping Summary")
    y -= 0.3*inch
    c.setFont("Helvetica", 10)
    for k, v in summary.items():
        c.drawString(1*inch, y, f"{k}: {v}")
        y -= 0.2*inch

    y -= 0.2*inch
    c.setFont("Helvetica-Bold", 12)
    c.drawString(1*inch, y, "Exceptions")
    y -= 0.25*inch
    c.setFont("Helvetica", 9)
    for ex in exceptions[:40]:
        line = f"{ex.get('LineID','')} | {ex.get('Description','')[:60]} | {ex.get('Error','')}"
        c.drawString(1*inch, y, line)
        y -= 0.18*inch
        if y < 1*inch:
            c.showPage()
            y = height - 1*inch
    c.save()
