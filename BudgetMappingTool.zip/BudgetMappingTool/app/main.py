
import os
import re
from pathlib import Path
import pandas as pd

try:
    import xlwings as xw
except Exception:
    xw = None

from utils import normalize_text, make_key, timestamp, load_csv, save_csv, load_yaml, fuzzy_score
from validators import validate_row
from ai_notes import generate_ai_notes

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
EXCEL = ROOT / "excel"
OUTPUTS = ROOT / "outputs"

def _load_settings(wb):
    sht = wb.sheets["Settings"]
    coa = sht.range("B2").value or "US"
    use_ai = bool(sht.range("B4").value)
    return {"coa": str(coa).strip().upper(), "use_ai": use_ai}

def _load_sample_budget():
    return pd.ExcelFile(DATA / "samples" / "sample_budget.xlsx")

def _load_coa(coa_code: str) -> pd.DataFrame:
    path = DATA / f"COA_{coa_code}.csv"
    df = pd.read_csv(path, dtype=str).fillna("")
    df["account_code"] = df["account_code"].astype(str)
    df["norm_keywords"] = df["keywords"].apply(lambda s: normalize_text(s))
    return df

def _load_rules() -> list:
    y = load_yaml(str(ROOT / "app" / "rules.yaml")) or {}
    return y.get("rules", [])

def _load_corrections() -> pd.DataFrame:
    path = DATA / "corrections.csv"
    if path.exists():
        return pd.read_csv(path, dtype=str).fillna("")
    return pd.DataFrame(columns=["key","account_code","account_name","source","notes","created_at"])

def _prepare_output_sheets(wb):
    for name in ["Mapped_Details","Mapped_Categories","Mapped_TopSheet","Change_Log","Summary","Exceptions"]:
        if name not in [s.name for s in wb.sheets]:
            wb.sheets.add(name)
        wb.sheets[name].used_range.clear_contents()

def _write_df(ws, df: pd.DataFrame):
    ws.range("A1").value = [list(df.columns)] + df.values.tolist()

def _exact_match(row, coa_df):
    code = str(row.get("Original_Account_Code","")).strip()
    if code and code in set(coa_df["account_code"]):
        hit = coa_df[coa_df["account_code"] == code].iloc[0]
        return code, hit["account_name"], "exact:code"
    desc = normalize_text(row.get("Description",""))
    for _, r in coa_df.iterrows():
        kws = [k.strip() for k in r["norm_keywords"].split(",") if k.strip()]
        if any(re.search(rf"\b{re.escape(k)}\b", desc) for k in kws):
            return r["account_code"], r["account_name"], "exact:keyword"
    return "", "", ""

def _rule_based(row, rules, coa_df):
    desc = row.get("Description","") or ""
    for rule in rules:
        patt = rule.get("pattern")
        if patt and re.search(patt, desc):
            code = str(rule.get("account_code","")).strip()
            hit = coa_df[coa_df["account_code"] == code]
            if not hit.empty:
                return code, hit.iloc[0]["account_name"], f"rule:{rule.get('note','')}"
    return "", "", ""

def _fuzzy_match(row, coa_df, threshold=87):
    desc = normalize_text(row.get("Description",""))
    best = ("", "", 0.0)
    for _, r in coa_df.iterrows():
        score = fuzzy_score(desc, r["norm_keywords"])
        if score > best[2]:
            best = (r["account_code"], r["account_name"], score)
    if best[2] >= threshold:
        return best[0], best[1], f"fuzzy:{int(best[2])}"
    return "", "", ""

def _correction_match(row, corrections_df):
    key = make_key(row)
    hit = corrections_df[corrections_df["key"] == key]
    if not hit.empty:
        r = hit.iloc[0]
        return r["account_code"], r["account_name"], "correction"
    return "", "", ""

def _build_change_log(before_df, after_df):
    merged = before_df.merge(after_df[["LineID","Mapped_Account_Code","Mapped_Account_Name","Match_Type"]], on="LineID", how="left")
    ch = merged[["LineID","Description","Original_Account_Code","Mapped_Account_Code","Mapped_Account_Name","Match_Type"]].copy()
    ch["Changed"] = (ch["Original_Account_Code"].fillna("") != ch["Mapped_Account_Code"].fillna(""))
    return ch

def run_mapping():
    if xw is None:
        raise RuntimeError("xlwings not available. Run from Excel with RunPython.")
    wb = xw.Book.caller()

    settings = _load_settings(wb)
    coa_df = _load_coa(settings["coa"])
    rules = _load_rules()
    corrections_df = _load_corrections()

    xls = _load_sample_budget()
    top = pd.read_excel(xls, "Top Sheet")
    cat = pd.read_excel(xls, "Categories")
    det = pd.read_excel(xls, "Details")

    _prepare_output_sheets(wb)
    det_before = det.copy()

    mapped_rows = []
    valid_codes = set(coa_df["account_code"])

    for _, row in det.iterrows():
        row = row.to_dict()
        code, name, mtype = _correction_match(row, corrections_df)
        if not code:
            code, name, mtype = _exact_match(row, coa_df)
        if not code:
            code, name, mtype = _rule_based(row, rules, coa_df)
        if not code:
            code, name, mtype = _fuzzy_match(row, coa_df)

        row["Mapped_Account_Code"] = code
        row["Mapped_Account_Name"] = name
        row["Match_Type"] = mtype

        errors = validate_row(row, valid_codes)
        row["Errors"] = "; ".join(errors)
        mapped_rows.append(row)

    mapped_df = pd.DataFrame(mapped_rows)
    ex_df = mapped_df[mapped_df["Errors"] != ""].copy()
    if not ex_df.empty:
        ex_df["Approve"] = ""
        ex_df["Approved_Code"] = ""
        ex_df["Notes"] = ""

    ch = _build_change_log(det_before, mapped_df)
    changed = ch[ch["Changed"]]

    summary = {
        "COA": settings["coa"],
        "Total Lines": len(mapped_df),
        "Exceptions": len(ex_df),
        "Changed": len(changed),
    }

    notes = generate_ai_notes(changed.to_dict(orient="records"), use_ai=settings["use_ai"])

    _write_df(wb.sheets["Mapped_Details"], mapped_df)
    _write_df(wb.sheets["Mapped_Categories"], cat)
    _write_df(wb.sheets["Mapped_TopSheet"], top)
    _write_df(wb.sheets["Exceptions"], ex_df if not ex_df.empty else pd.DataFrame(columns=["No Exceptions"]))
    _write_df(wb.sheets["Change_Log"], ch)

    s = wb.sheets["Summary"]
    s.range("A1").value = [["Metric","Value"], ["COA", summary["COA"]], ["Total Lines", summary["Total Lines"]], ["Exceptions", summary["Exceptions"]], ["Changed", summary["Changed"]]]
    s.range("A6").value = [["Notes"], [notes]]

def apply_approved_corrections():
    if xw is None:
        raise RuntimeError("xlwings not available. Run from Excel with RunPython.")
    wb = xw.Book.caller()
    ex = wb.sheets["Exceptions"].range("A1").options(pd.DataFrame, header=1, index=False, expand='table').value
    if ex is None or ex.empty or "Approve" not in ex.columns:
        return

    from utils import timestamp, make_key
    corrections = []
    for _, r in ex.iterrows():
        if str(r.get("Approve","")).strip().upper() == "Y":
            code = str(r.get("Approved_Code") or r.get("Mapped_Account_Code") or "").strip()
            name = str(r.get("Mapped_Account_Name") or "")
            key = make_key(r.to_dict())
            if code:
                corrections.append({
                    "key": key,
                    "account_code": code,
                    "account_name": name,
                    "source": "manual_approval",
                    "notes": str(r.get("Notes","")),
                    "created_at": timestamp(),
                })

    corr_path = DATA / "corrections.csv"
    if corrections:
        if corr_path.exists():
            df = pd.read_csv(corr_path, dtype=str).fillna("")
        else:
            df = pd.DataFrame(columns=["key","account_code","account_name","source","notes","created_at"])
        df = pd.concat([df, pd.DataFrame(corrections)], ignore_index=True)
        df.drop_duplicates(subset=["key"], keep="last", inplace=True)
        df.to_csv(corr_path, index=False)

    run_mapping()
