
import re
from datetime import datetime

def normalize_text(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())

def make_key(row: dict) -> str:
    base = f"{normalize_text(row.get('Description',''))}|{normalize_text(row.get('Vendor',''))}|{round(float(row.get('Amount',0)),2)}"
    return base

def timestamp() -> str:
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

def load_csv(path: str):
    import pandas as pd
    return pd.read_csv(path, dtype=str).fillna("")

def save_csv(df, path: str):
    df.to_csv(path, index=False)

def load_yaml(path: str):
    import yaml
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def fuzzy_score(a: str, b: str) -> float:
    from rapidfuzz import fuzz
    return fuzz.token_set_ratio(a, b)
